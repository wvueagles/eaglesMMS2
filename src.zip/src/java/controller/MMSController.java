package controller;

import java.io.PrintWriter;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.ServletException;
import java.util.regex.Matcher; 
import java.util.regex.Pattern;
import java.io.IOException;
import java.sql.*;


/**
 *
 * 
 */
public class MMSController extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    MMSManager mms = new MMSManager();   //should be attached per user session

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>ServletController</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet MMSController at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
      
        switch (action) {
  //TODO we propably do need an exit to clear data not sure what data yet
  //Space holders for us to work with
            case ("exit"):     
                //clear clean up
                request.setAttribute("responseMessage", "Clears Properties.");
                request.getRequestDispatcher("/exit.jsp").forward(request, response);
                break;
             case ("potholes"):  
                 //get and validate input
                String location = request.getParameter("location");
                String severity = request.getParameter("severity");
                String comments = request.getParameter("comments");

                if(!validateString(location) || !validateString(comments)){
                    request.setAttribute("responseMessage", "Text may not contain special characters");
                    request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                }
                if(location == ""){
                    request.setAttribute("responseMessage", "Location Required");
                    request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                }
                if(!validateInt(severity)){
                    request.setAttribute("responseMessage", "Severity must be an integer");
                    request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                }
                if(Integer.parseInt(severity) < 1 || Integer.parseInt(severity) > 5){
                    request.setAttribute("responseMessage", "Severity must be an integer between 1 and 5");
                    request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                }
                
                //Database connection info, change this if yours is different
                String url = "jdbc:postgresql://localhost:5432/eagles_mms";
                String user = "admin";
                String password = "admin";
                
                Connection conn = null;

                try {
                    //This line is necessary for java to understand how to use the postgres jar file
                    //Put the postgres jdbc driver in your apache lib folder and add it to your project
                    Class.forName("org.postgresql.Driver");
                    conn = DriverManager.getConnection(url, user, password);
                    String SQL = "INSERT INTO potholes(location, severity, comments) " + "VALUES(?,?,?)";
 
                    long id = 0;
 
                    PreparedStatement pstmt = conn.prepareStatement(SQL,Statement.RETURN_GENERATED_KEYS);

                    pstmt.setString(1, location);
                    pstmt.setInt(2, Integer.parseInt(severity));
                    pstmt.setString(3, comments);

                    int affectedRows = pstmt.executeUpdate();
                    // check the affected rows 
                    if (affectedRows > 0) {
                        // get the ID back
                        try (ResultSet rs = pstmt.getGeneratedKeys()) {
                            if (rs.next()) {
                                id = rs.getLong(1);
                            }
                        } catch (SQLException ex) {
                            request.setAttribute("responseMessage", ex.getMessage());
                            request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                        }
                    }
                    } 
                catch (Exception e) {
                    request.setAttribute("responseMessage", e.getMessage());
                    request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                }
                request.setAttribute("responseMessage", "Successfully entered record");
                request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                break;
 /*           case ("potholes"):  
                  case ("quiz1"):
                QuizManager.setQuizStart();
                request.setAttribute("quizquestion", QuizManager.getQuizQuestion());
                request.getRequestDispatcher("/quiz2.jsp").forward(request, response);
                break; //end case quiz1
            case ("potholes2")://example of auto going to a differet page
/*            case ("pothole2"):
                if (MMSManager.isPotHoleDataValid(request.getParameter("potholelocation"))) {
                    request.setAttribute("responseanswer", "location is valid.");
                } else {
                    request.setAttribute("responseanswer", "That is not a valid location.");
                }
                request.getRequestDispatcher("/pothole2.jsp").forward(request, response);
                break; //end case pothole2
 
                String location = request.getParameter("location");
                String severity = request.getParameter("severity");
                String comments = request.getParameter("comments");

                if(!validateString(location) || !validateString(comments)){
                    request.setAttribute("responseMessage", "Text may not contain special characters");
                    request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                }
                if(!validateInt(severity)){
                    request.setAttribute("responseMessage", "Severity must be an integer");
                    request.getRequestDispatcher("/pothole.jsp").forward(request, response);
                }
                request.setAttribute("responseMessage", "Successfully entered record");
                request.getRequestDispatcher("/pothole.jsp").forward(request, response);

                break;
 */           case ("person"):  //go to the person entry page   
              //  request.setAttribute("responseMessage", MMSManager.displayPersonData()));
                request.setAttribute("responseMessage", "person page");
                request.getRequestDispatcher("/person.jsp").forward(request, response);
                break;  // end person switch
            case ("repair"):  //go to the repair entry page   
              //  request.setAttribute("responseMessage", MMSManager.displayRepairData()));
                request.setAttribute("responseMessage", "repair page");
                request.getRequestDispatcher("/repair.jsp").forward(request, response);
                break;  // end repair switch
            case ("workorder"):  //go to the workorder entry page   
              //  request.setAttribute("responseMessage", MMSManager.displaywWorkorderData()));
                request.setAttribute("responseMessage", "workorder page");
                request.getRequestDispatcher("/workorder.jsp").forward(request, response);
                break;  // end workorder switch
            case ("report"):  //go to the workorder entry page   
              //  request.setAttribute("responseMessage", MMSManager.displaywReportData()));
                request.setAttribute("responseMessage", "report page");
                request.getRequestDispatcher("/report.jsp").forward(request, response);
                break;  // end report switch   
            default:
        }

    }
 private static String realPath;
   void setRealPath(){
         realPath=getServletContext().getRealPath("");
      }
   
   private static Boolean validateString(String input){
        Pattern p = Pattern.compile("[^a-z0-9,. ]", Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(input);
        return !(m.find());
   }
   
   private static Boolean validateInt(String input){
        try {  
            Integer.parseInt(input);
            return true;
        } catch(NumberFormatException e){  
            return false;  
        }  
   }
 
  public static  String getFilePath(){
         return realPath; 
      }
    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
   

}
